# Firebase-Multiplayer-Game
A two player Rock Paper Scissor game using Firebase. 

## You can see it live here: https://jpdevspace.github.io/Firebase-Multiplayer-Game/.

Technologies used for this project: Firebase, JavaScript, Bootstrap v4, HTML and CSS

![alt text][screenshot]

[screenshot]: https://github.com/jpdevspace/Firebase-Multiplayer-Game/blob/master/assets/imgs/screenshot.png "Game Screenshot"

### INSTRUCTIONS
Type in your name in the box to start. It's a two player game so you will have to wait until someone joins (or open a second browser window).
From there is a regular Rock Paper Scissors game, with a chat. All built with Firebase.
